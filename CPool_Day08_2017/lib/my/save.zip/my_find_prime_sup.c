/*
** EPITECH PROJECT, 2017
** my_find_prime_sup
** File description:
** Desc
*/

int my_find_prime_sup(int nb)
{
	return (0);
}
