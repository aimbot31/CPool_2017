/*
** EPITECH PROJECT, 2017
** my_is_prime
** File description:
** Desc
*/

int my_is_prime(int nb)
{
	return (0);
}
