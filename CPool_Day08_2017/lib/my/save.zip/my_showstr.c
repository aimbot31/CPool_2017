/*
** EPITECH PROJECT, 2017
** my_showstr
** File description:
** Desc
*/

int my_showstr(char const *str)
{
	return (0);
}
