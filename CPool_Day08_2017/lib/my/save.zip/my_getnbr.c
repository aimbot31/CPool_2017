/*
** EPITECH PROJECT, 2017
** my_getnbr
** File description:
** Desc
*/

int my_getnbr(char const *str)
{
	return (0);
}
