/*
** EPITECH PROJECT, 2017
** my_compute_square_root
** File description:
** Desc
*/

int my_compute_square_root(int nb)
{
	return (0);
}
